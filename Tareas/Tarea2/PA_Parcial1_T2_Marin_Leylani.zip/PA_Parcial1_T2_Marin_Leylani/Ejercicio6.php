<?php

function decimalBinario($numero) {
    //si el numero es 0 o 1 el resultado sera 0 y 1 
    if($numero === 0) return 0;
    if($numero === 1) return 1;

    return decimalBinario(intdiv($numero, 2)) . ($numero % 2);
}
echo "<h3> Ejercicio 6: De Decimal a Binario </h3>";
echo "El numero 10 en binario es: " . decimalBinario(10) . "<br>";
echo "El numero 54 en binario es: " . decimalBinario(54) . "<br>";
?>