<?php

function sumaArreglo($arreglo){
    // si mi arreglo esta vacio , mi resultado sera 0 
    if(empty($arreglo)){
        return 0;
    }
    $primerElemento = array_shift($arreglo);
    return $primerElemento + sumaArreglo($arreglo);
}
echo "<h3> Ejercicio 7: Suma Arreglo </h3>";
$numeros = [5, 10, 15, 20];
echo "La suma de [5, 10, 15, 20] es: " . sumaArreglo($numeros) . "<br>";
?>