<?php

function Euclides($a, $b) {
    // cuando el residuo ($b) llegue a 0 el MCD sera ($a)
    if($b === 0) {
        return $a;
    }
    return Euclides($b, $a % $b);
}
echo "<h3> Ejercicio 5 : Euclides (Maximo Comun Divisor) </h3>";
echo "Maximo Comun Divisor de 48 y 18 es: " . Euclides(48, 18) . "<br>";
echo "Maximo Comun Divisor de 56 y 42 es: " . Euclides(56, 42) . "<br>";
?>
