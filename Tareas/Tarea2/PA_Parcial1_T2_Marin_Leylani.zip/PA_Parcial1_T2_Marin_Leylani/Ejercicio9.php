<?php

function cuentaVocales($cadena) {
    // si la cadena esta vacia , no tiene vocales osea 0 
    if($cadena === ""){
        return 0;
    }
    $primerCaracter = strtolower($cadena[0]);
    $vocales = ['a', 'e', 'i', 'o', 'u'];
    $esVocal = in_array($primerCaracter, $vocales) ? 1 : 0;

    return $esVocal + cuentaVocales(substr($cadena, 1));
}
echo "<h3> Ejercicio 9: Contar Vocales </h3>";
echo "Vocales 'hola soy leylani': " . cuentaVocales("hola soy leylani") . "<br>";
echo "Vocales 'estos son mis ejercicios de programacion': " . 
cuentaVocales("estos son mis ejercicios de programacion") . "<br>";
?>