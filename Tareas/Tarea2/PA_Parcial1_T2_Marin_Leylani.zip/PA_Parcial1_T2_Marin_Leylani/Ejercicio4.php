<?php

function palindrimo($cadena) {
    $cadena = strtolower(str_replace('', '', $cadena));
    $longitud = strlen($cadena);

    // si tiene 0 o 1 se lee igual al derecho o al reves 
    if($longitud <= 1){
        return true;
    }
    // si mis extremos no coinciden nos es palindromo 
    if($cadena[0] !== $cadena[$longitud - 1]) {
        return false;
    }
    return palindrimo(substr($cadena, 1, $longitud - 2));
}
echo "<h3> Ejercicio 4: Palindromo </h3>";
echo "'Anita lava la tina' es palindromo?: " . 
(palindrimo("Anita lava la tina") ? "si" : "no") . "<br>";
echo "'programacion' es palindromo?: " . (palindrimo("programacion")
 ? "si" : "no") . "<br>";
 ?>