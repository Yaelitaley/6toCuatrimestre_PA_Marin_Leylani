<?php

function sumarParesHataN($n){
    // si llego a 0 la suma es 0 
    if($n <= 0){
        return 0;
    }
    if($n % 2 === 0){
        return $n + sumarParesHataN($n - 2);
    }else{
        return sumarParesHataN($n - 1);
    }
}
echo "<h3> E jercicio 10: Sumar Pares Hasta N</h3>";
echo "suma pares hasta 10 (10+8+6+4+2): " . sumarParesHataN(10) . "<br>";
echo "suma pares hasta 14 (14+12+10+8+6+4+2): " . sumarParesHataN(14) . "<br>";
?>