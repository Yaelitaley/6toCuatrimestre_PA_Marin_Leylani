<?php

function calcularPotencia($base, $exponente) {
// cualquier numero elevado a la 0 da 1
if($exponente === 0){
    return 1;
}
return $base * calcularPotencia($base, $exponente - 1);
}
echo "<h3> Ejercicio 1: potencia </h3>";
echo "2 elevado a la 5 es: " . calcularPotencia(2, 5) . "<br>";
echo "5 elevado a la 3 es: " . calcularPotencia(5, 3) . "<br>";
?>