<?php

function existeArreglo($arreglo, $existe){
    // si el arreglo queda vacio el elemnento no existira 
    if(empty($arreglo)){
        return false;
    }
    if($arreglo[0] === $existe){
        return true;
    }
    array_shift($arreglo);
    return existeArreglo($arreglo, $existe);
}
echo "<h3> Ejercicio 8: Existe elemneto en arreglo </h3>";
$materias = ["español", "matematicas", "fisica", "historia"];
echo "Existe 'historia' ?: " . (existeArreglo($materias, "historia") ? "si" : "no") . "<br>";
echo "Existe 'programacion' ?: " . (existeArreglo($materias, "programacion") ? "si" : "no") . "<br>";
?>