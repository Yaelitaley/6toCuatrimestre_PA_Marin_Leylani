<?php

function multiplicacionConSumas($a, $b) {
    // si se multiplica por 0 mi resultado va a ser 0
    if($b === 0) {
        return 0;
    }
    return $a + multiplicacionConSumas($a, $b - 1);
}
echo "<h3>Ejercicio 2: Multiplicacion Con Sumas</h3>";
echo "4 multiplicado por 6 es: " . multiplicacionConSumas(4, 6) . "<br>";
echo "3 multiplicado por 5 es: " . multiplicacionConSumas(3, 5) . "<br>";
?>
 