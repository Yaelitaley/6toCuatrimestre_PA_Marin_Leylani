<?php

function cadenaTexto($cadena) {
    //si mi cadena de texto esta vacia , va a dar 0
    if($cadena === "") {
        return 0;
    }
    $restoCadena = substr($cadena, 1);
    return 1 + cadenaTexto($restoCadena);
}
echo "<h3> Ejercicio 3: Contar Cadena de Texto </h3>";
echo "longitud de 'hola': " . cadenaTexto("hola") . "<br>";
echo "longitud de 'leylani': " . cadenaTexto("leylani") . "<br>";
echo "longitud de 'ejercicios': " . cadenaTexto("ejercicios") . "<br>";
?>