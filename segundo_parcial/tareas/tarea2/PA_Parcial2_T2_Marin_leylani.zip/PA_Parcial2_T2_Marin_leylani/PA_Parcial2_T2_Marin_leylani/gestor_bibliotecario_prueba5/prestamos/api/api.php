<?php
require_once('../../config/connection.php'); 
header("Access-Control-Allow-Origin: *"); 
header("Content-Type: application/json; charset=UTF-8"); 
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE"); 
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

$select_base = "SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos";
$estados_validos = ['prestado', 'devuelto', 'retrasado'];


if ($method === 'GET') {

    // Buscar préstamo por ID

    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("$select_base WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            echo json_encode($resultado->fetch_assoc());
        } else {
            http_response_code(404);
            echo json_encode(["mensaje" => "Préstamo no encontrado"]);
        }
        $stmt->close();


    // Buscar préstamos por usuario

    } elseif (isset($_GET['id_usuario'])) {
        $id_usuario = intval($_GET['id_usuario']);
        $stmt = $conn->prepare("$select_base WHERE id_usuario = ?");
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $prestamos = array();
        while ($row = $resultado->fetch_assoc()) {
            $prestamos[] = $row;
        }

        if (count($prestamos) > 0) {
            echo json_encode($prestamos);
        } else {
            http_response_code(404);
            echo json_encode(["mensaje" => "No se encontraron préstamos para ese usuario"]);
        }
        $stmt->close();


    // Buscar préstamos x estado

    } elseif (isset($_GET['estado'])) {
        $estado = trim($_GET['estado']);
        $stmt = $conn->prepare("$select_base WHERE estado = ?");
        $stmt->bind_param("s", $estado);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $prestamos = array();
        while ($row = $resultado->fetch_assoc()) {
            $prestamos[] = $row;
        }

        if (count($prestamos) > 0) {
            echo json_encode($prestamos);
        } else {
            http_response_code(404);
            echo json_encode(["mensaje" => "No se encontraron préstamos con ese estado"]);
        }
        $stmt->close();


    // Préstamos vencidos

    } elseif (isset($_GET['atrasados'])) {
        $stmt = $conn->prepare("$select_base WHERE estado = 'prestado' AND fecha_devolucion < CURDATE()");
        $stmt->execute();
        $resultado = $stmt->get_result();

        $prestamos = array();
        while ($row = $resultado->fetch_assoc()) {
            $prestamos[] = $row;
        }
        echo json_encode($prestamos);
        $stmt->close();


    // Buscar todos 

    } else {
        $stmt = $conn->prepare($select_base);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $prestamos = array();
        while ($row = $resultado->fetch_assoc()) {
            $prestamos[] = $row;
        }
        echo json_encode($prestamos);
        $stmt->close();
    }


// Crear uno

} elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    $requeridos = ['id_usuario', 'fecha_prestamo', 'fecha_devolucion'];
    foreach ($requeridos as $campo) {
        if (!isset($data[$campo]) || trim(strval($data[$campo])) === '') {
            http_response_code(400);
            echo json_encode(["mensaje" => "El campo '$campo' es obligatorio"]);
            $conn->close();
            exit;
        }
    }

    $id_usuario = intval($data['id_usuario']);
    $fecha_prestamo = trim($data['fecha_prestamo']);
    $fecha_devolucion = trim($data['fecha_devolucion']);
    $estado = isset($data['estado']) ? trim($data['estado']) : 'prestado';

    // Validar formato de fechas
    if (!DateTime::createFromFormat('Y-m-d', $fecha_prestamo) || !DateTime::createFromFormat('Y-m-d', $fecha_devolucion)) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Las fechas deben tener el formato YYYY-MM-DD"]);
        $conn->close();
        exit;
    }

    if ($fecha_devolucion < $fecha_prestamo) {
        http_response_code(400);
        echo json_encode(["mensaje" => "La fecha de devolución no puede ser anterior a la fecha de préstamo"]);
        $conn->close();
        exit;
    }

    if (!in_array($estado, $estados_validos)) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El estado debe ser: prestado, devuelto o retrasado"]);
        $conn->close();
        exit;
    }

    // Validar que la FK de usuario sirva 
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El usuario indicado no existe"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $stmt = $conn->prepare("INSERT INTO prestamos (id_usuario, fecha_prestamo, fecha_devolucion, estado) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado);

    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode([
            "mensaje" => "Préstamo creado correctamente",
            "id" => $stmt->insert_id
        ]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al crear el préstamo"]);
    }
    $stmt->close();


// Actualizar completamente

} elseif ($method === 'PUT') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del préstamo"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Préstamo no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $data = json_decode(file_get_contents("php://input"), true);

    $requeridos = ['id_usuario', 'fecha_prestamo', 'fecha_devolucion'];
    foreach ($requeridos as $campo) {
        if (!isset($data[$campo]) || trim(strval($data[$campo])) === '') {
            http_response_code(400);
            echo json_encode(["mensaje" => "El campo '$campo' es obligatorio"]);
            $conn->close();
            exit;
        }
    }

    $id_usuario = intval($data['id_usuario']);
    $fecha_prestamo = trim($data['fecha_prestamo']);
    $fecha_devolucion = trim($data['fecha_devolucion']);
    $estado = isset($data['estado']) ? trim($data['estado']) : 'prestado';

    if (!DateTime::createFromFormat('Y-m-d', $fecha_prestamo) || !DateTime::createFromFormat('Y-m-d', $fecha_devolucion)) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Las fechas deben tener el formato YYYY-MM-DD"]);
        $conn->close();
        exit;
    }

    if ($fecha_devolucion < $fecha_prestamo) {
        http_response_code(400);
        echo json_encode(["mensaje" => "La fecha de devolución no puede ser anterior a la fecha de préstamo"]);
        $conn->close();
        exit;
    }

    if (!in_array($estado, $estados_validos)) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El estado debe ser: prestado, devuelto o retrasado"]);
        $conn->close();
        exit;
    }

    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El usuario indicado no existe"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $stmt = $conn->prepare("UPDATE prestamos SET id_usuario = ?, fecha_prestamo = ?, fecha_devolucion = ?, estado = ? WHERE id = ?");
    $stmt->bind_param("isssi", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado, $id);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Préstamo actualizado correctamente", "id" => $id]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al actualizar el préstamo"]);
    }
    $stmt->close();


// Actualizar únicamente algunos campos 

} elseif ($method === 'PATCH') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del préstamo"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id, fecha_prestamo, fecha_devolucion FROM prestamos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    if ($resultado->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Préstamo no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $prestamo_actual = $resultado->fetch_assoc();
    $stmt->close();

    $data = json_decode(file_get_contents("php://input"), true);

    if (!is_array($data) || count($data) === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe enviar al menos un campo para actualizar"]);
        $conn->close();
        exit;
    }

    if (isset($data['estado']) && !in_array(trim($data['estado']), $estados_validos)) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El estado debe ser: prestado, devuelto o retrasado"]);
        $conn->close();
        exit;
    }

    if (isset($data['id_usuario'])) {
        $id_usuario_check = intval($data['id_usuario']);
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id_usuario_check);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(["mensaje" => "El usuario indicado no existe"]);
            $stmt->close();
            $conn->close();
            exit;
        }
        $stmt->close();
    }

    $fecha_prestamo_final = isset($data['fecha_prestamo']) ? trim($data['fecha_prestamo']) : $prestamo_actual['fecha_prestamo'];
    $fecha_devolucion_final = isset($data['fecha_devolucion']) ? trim($data['fecha_devolucion']) : $prestamo_actual['fecha_devolucion'];

    if (isset($data['fecha_prestamo']) && !DateTime::createFromFormat('Y-m-d', $fecha_prestamo_final)) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El campo 'fecha_prestamo' debe tener el formato YYYY-MM-DD"]);
        $conn->close();
        exit;
    }
    if (isset($data['fecha_devolucion']) && !DateTime::createFromFormat('Y-m-d', $fecha_devolucion_final)) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El campo 'fecha_devolucion' debe tener el formato YYYY-MM-DD"]);
        $conn->close();
        exit;
    }
    if ($fecha_devolucion_final < $fecha_prestamo_final) {
        http_response_code(400);
        echo json_encode(["mensaje" => "La fecha de devolución no puede ser anterior a la fecha de préstamo"]);
        $conn->close();
        exit;
    }

    $campos_permitidos = ['id_usuario', 'fecha_prestamo', 'fecha_devolucion', 'estado'];
    $sets = [];
    $tipos = "";
    $valores = [];

    foreach ($campos_permitidos as $campo) {
        if (isset($data[$campo])) {
            $sets[] = "$campo = ?";
            if ($campo === 'id_usuario') {
                $tipos .= "i";
                $valores[] = intval($data[$campo]);
            } else {
                $tipos .= "s";
                $valores[] = trim($data[$campo]);
            }
        }
    }

    if (count($sets) === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "No se enviaron campos válidos para actualizar"]);
        $conn->close();
        exit;
    }

    $sql = "UPDATE prestamos SET " . implode(", ", $sets) . " WHERE id = ?";
    $tipos .= "i";
    $valores[] = $id;

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($tipos, ...$valores);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Préstamo actualizado correctamente", "id" => $id]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al actualizar el préstamo"]);
    }
    $stmt->close();


// Eliminar uno

} elseif ($method === 'DELETE') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del préstamo"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Préstamo no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    // eliminamos en cascada 
    $stmt = $conn->prepare("DELETE FROM prestamos WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Préstamo eliminado correctamente"]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al eliminar el préstamo"]);
    }
    $stmt->close();


} else {
    http_response_code(405);
    echo json_encode(["mensaje" => "Método no permitido"]);
}

$conn->close();
