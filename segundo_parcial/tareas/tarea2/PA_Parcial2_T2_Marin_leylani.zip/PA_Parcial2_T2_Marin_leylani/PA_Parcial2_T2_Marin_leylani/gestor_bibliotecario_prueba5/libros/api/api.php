<?php
require_once('../../config/connection.php'); 
header("Access-Control-Allow-Origin: *"); 
header("Content-Type: application/json; charset=UTF-8"); 
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'GET') {
    http_response_code(405);
    echo json_encode(["mensaje" => "Método no permitido. Esta API solo acepta GET"]);
    $conn->close();
    exit;
}

$select_base = "SELECT id, titulo, isbn, anio_publicacion, editorial, cantidad, disponibles, id_categoria FROM libros";


// Buscar libro por ID

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("$select_base WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        echo json_encode($resultado->fetch_assoc());
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "Libro no encontrado"]);
    }
    $stmt->close();


// Buscar libro por título

} elseif (isset($_GET['titulo'])) {
    $titulo_param = "%" . trim($_GET['titulo']) . "%";
    $stmt = $conn->prepare("$select_base WHERE titulo LIKE ?");
    $stmt->bind_param("s", $titulo_param);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $libros = array();
    while ($row = $resultado->fetch_assoc()) {
        $libros[] = $row;
    }

    if (count($libros) > 0) {
        echo json_encode($libros);
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "No se encontraron libros con ese título"]);
    }
    $stmt->close();


// Buscar libro x año de publicación

} elseif (isset($_GET['anio'])) {
    $anio = intval($_GET['anio']);
    $stmt = $conn->prepare("$select_base WHERE anio_publicacion = ?");
    $stmt->bind_param("i", $anio);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $libros = array();
    while ($row = $resultado->fetch_assoc()) {
        $libros[] = $row;
    }

    if (count($libros) > 0) {
        echo json_encode($libros);
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "No se encontraron libros publicados en ese año"]);
    }
    $stmt->close();


// Libros que tienen al menos un ejemplar disponible

} elseif (isset($_GET['disponibles'])) {
    $stmt = $conn->prepare("$select_base WHERE disponibles > 0");
    $stmt->execute();
    $resultado = $stmt->get_result();

    $libros = array();
    while ($row = $resultado->fetch_assoc()) {
        $libros[] = $row;
    }
    echo json_encode($libros);
    $stmt->close();


// Libros filtrados por categoría

} elseif (isset($_GET['id_categoria'])) {
    $id_categoria = intval($_GET['id_categoria']);
    $stmt = $conn->prepare("$select_base WHERE id_categoria = ?");
    $stmt->bind_param("i", $id_categoria);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $libros = array();
    while ($row = $resultado->fetch_assoc()) {
        $libros[] = $row;
    }

    if (count($libros) > 0) {
        echo json_encode($libros);
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "No se encontraron libros para esa categoría"]);
    }
    $stmt->close();


// Libros filtrados por editorial

} elseif (isset($_GET['editorial'])) {
    $editorial_param = "%" . trim($_GET['editorial']) . "%";
    $stmt = $conn->prepare("$select_base WHERE editorial LIKE ?");
    $stmt->bind_param("s", $editorial_param);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $libros = array();
    while ($row = $resultado->fetch_assoc()) {
        $libros[] = $row;
    }

    if (count($libros) > 0) {
        echo json_encode($libros);
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "No se encontraron libros de esa editorial"]);
    }
    $stmt->close();

// Buscar todos 

} else {
    $stmt = $conn->prepare($select_base);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $libros = array();
    while ($row = $resultado->fetch_assoc()) {
        $libros[] = $row;
    }
    echo json_encode($libros);
    $stmt->close();
}

$conn->close();
