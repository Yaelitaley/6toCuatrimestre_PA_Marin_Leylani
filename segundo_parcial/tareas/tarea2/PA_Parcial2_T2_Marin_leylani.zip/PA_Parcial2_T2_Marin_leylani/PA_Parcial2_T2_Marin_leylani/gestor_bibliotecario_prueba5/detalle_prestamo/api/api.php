<?php
require_once('../../config/connection.php'); 
header("Access-Control-Allow-Origin: *"); 
header("Content-Type: application/json; charset=UTF-8"); 
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE"); 
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

$select_base = "SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo";


if ($method === 'GET') {

    // Buscar registro por ID

    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("$select_base WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            echo json_encode($resultado->fetch_assoc());
        } else {
            http_response_code(404);
            echo json_encode(["mensaje" => "Registro no encontrado"]);
        }
        $stmt->close();


    // Buscar detalle 

    } elseif (isset($_GET['id_prestamo'])) {
        $id_prestamo = intval($_GET['id_prestamo']);
        $stmt = $conn->prepare("$select_base WHERE id_prestamo = ?");
        $stmt->bind_param("i", $id_prestamo);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $detalles = array();
        while ($row = $resultado->fetch_assoc()) {
            $detalles[] = $row;
        }

        if (count($detalles) > 0) {
            echo json_encode($detalles);
        } else {
            http_response_code(404);
            echo json_encode(["mensaje" => "No se encontraron registros para ese préstamo"]);
        }
        $stmt->close();


    // Buscar detalle x libro

    } elseif (isset($_GET['id_libro'])) {
        $id_libro = intval($_GET['id_libro']);
        $stmt = $conn->prepare("$select_base WHERE id_libro = ?");
        $stmt->bind_param("i", $id_libro);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $detalles = array();
        while ($row = $resultado->fetch_assoc()) {
            $detalles[] = $row;
        }

        if (count($detalles) > 0) {
            echo json_encode($detalles);
        } else {
            http_response_code(404);
            echo json_encode(["mensaje" => "No se encontraron registros para ese libro"]);
        }
        $stmt->close();


    // Buscar todos

    } else {
        $stmt = $conn->prepare($select_base);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $detalles = array();
        while ($row = $resultado->fetch_assoc()) {
            $detalles[] = $row;
        }
        echo json_encode($detalles);
        $stmt->close();
    }


// Agregar un detalle 

} elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['id_prestamo']) || trim(strval($data['id_prestamo'])) === '' ||
        !isset($data['id_libro']) || trim(strval($data['id_libro'])) === '') {
        http_response_code(400);
        echo json_encode(["mensaje" => "Los campos 'id_prestamo' e 'id_libro' son obligatorios"]);
        $conn->close();
        exit;
    }

    $id_prestamo = intval($data['id_prestamo']);
    $id_libro = intval($data['id_libro']);
    $cantidad = isset($data['cantidad']) ? intval($data['cantidad']) : 1;

    if ($cantidad <= 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "La cantidad debe ser un número mayor a 0"]);
        $conn->close();
        exit;
    }

    // Validar que la FK exista
    $stmt = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
    $stmt->bind_param("i", $id_prestamo);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El préstamo indicado no existe"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    // Validar que la FK de libro funcione 
    $stmt = $conn->prepare("SELECT id FROM libros WHERE id = ?");
    $stmt->bind_param("i", $id_libro);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El libro indicado no existe"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $stmt = $conn->prepare("INSERT INTO detalle_prestamo (id_prestamo, id_libro, cantidad) VALUES (?, ?, ?)");
    $stmt->bind_param("iii", $id_prestamo, $id_libro, $cantidad);

    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode([
            "mensaje" => "Detalle de préstamo agregado correctamente",
            "id" => $stmt->insert_id
        ]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al agregar el detalle de préstamo"]);
    }
    $stmt->close();


// Actualizar completamente 

} elseif ($method === 'PUT') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del detalle"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id FROM detalle_prestamo WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Registro no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['id_prestamo']) || trim(strval($data['id_prestamo'])) === '' ||
        !isset($data['id_libro']) || trim(strval($data['id_libro'])) === '') {
        http_response_code(400);
        echo json_encode(["mensaje" => "Los campos 'id_prestamo' e 'id_libro' son obligatorios"]);
        $conn->close();
        exit;
    }

    $id_prestamo = intval($data['id_prestamo']);
    $id_libro = intval($data['id_libro']);
    $cantidad = isset($data['cantidad']) ? intval($data['cantidad']) : 1;

    if ($cantidad <= 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "La cantidad debe ser un número mayor a 0"]);
        $conn->close();
        exit;
    }

    $stmt = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
    $stmt->bind_param("i", $id_prestamo);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El préstamo indicado no existe"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT id FROM libros WHERE id = ?");
    $stmt->bind_param("i", $id_libro);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El libro indicado no existe"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $stmt = $conn->prepare("UPDATE detalle_prestamo SET id_prestamo = ?, id_libro = ?, cantidad = ? WHERE id = ?");
    $stmt->bind_param("iiii", $id_prestamo, $id_libro, $cantidad, $id);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Detalle actualizado correctamente", "id" => $id]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al actualizar el detalle"]);
    }
    $stmt->close();


// Actualizar solo cantitad 

} elseif ($method === 'PATCH') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del detalle"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id FROM detalle_prestamo WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Registro no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['cantidad']) || trim(strval($data['cantidad'])) === '') {
        http_response_code(400);
        echo json_encode(["mensaje" => "El campo 'cantidad' es obligatorio"]);
        $conn->close();
        exit;
    }

    $cantidad = intval($data['cantidad']);
    if ($cantidad <= 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "La cantidad debe ser un número mayor a 0"]);
        $conn->close();
        exit;
    }

    $stmt = $conn->prepare("UPDATE detalle_prestamo SET cantidad = ? WHERE id = ?");
    $stmt->bind_param("ii", $cantidad, $id);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Cantidad actualizada correctamente", "id" => $id, "cantidad" => $cantidad]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al actualizar la cantidad"]);
    }
    $stmt->close();


// Eliminar un detalle

} elseif ($method === 'DELETE') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del detalle"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id FROM detalle_prestamo WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Registro no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM detalle_prestamo WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Detalle eliminado correctamente"]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al eliminar el detalle"]);
    }
    $stmt->close();


} else {
    http_response_code(405);
    echo json_encode(["mensaje" => "Método no permitido"]);
}

$conn->close();
