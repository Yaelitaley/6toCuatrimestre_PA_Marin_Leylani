<?php
require_once('../../config/connection.php'); 
header("Access-Control-Allow-Origin: *"); 
header("Content-Type: application/json; charset=UTF-8"); 
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE"); 
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

$select_base = "SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios";


if ($method === 'GET') {

    // Buscar usuario por ID

    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("$select_base WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            echo json_encode($resultado->fetch_assoc());
        } else {
            http_response_code(404);
            echo json_encode(["mensaje" => "Usuario no encontrado"]);
        }
        $stmt->close();


    // Buscar usuario por nombre

    } elseif (isset($_GET['nombre'])) {
        $nombre_param = "%" . trim($_GET['nombre']) . "%";
        $stmt = $conn->prepare("$select_base WHERE nombre LIKE ?");
        $stmt->bind_param("s", $nombre_param);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $usuarios = array();
        while ($row = $resultado->fetch_assoc()) {
            $usuarios[] = $row;
        }

        if (count($usuarios) > 0) {
            echo json_encode($usuarios);
        } else {
            http_response_code(404);
            echo json_encode(["mensaje" => "No se encontraron usuarios con ese nombre"]);
        }
        $stmt->close();


    // Buscar usuario  x correo

    } elseif (isset($_GET['correo'])) {
        $correo_param = trim($_GET['correo']);
        $stmt = $conn->prepare("$select_base WHERE correo = ?");
        $stmt->bind_param("s", $correo_param);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            echo json_encode($resultado->fetch_assoc());
        } else {
            http_response_code(404);
            echo json_encode(["mensaje" => "No se encontró un usuario con ese correo"]);
        }
        $stmt->close();


    // Usuarios activos

    } elseif (isset($_GET['activo'])) {
        $stmt = $conn->prepare("$select_base WHERE activo = 1");
        $stmt->execute();
        $resultado = $stmt->get_result();

        $usuarios = array();
        while ($row = $resultado->fetch_assoc()) {
            $usuarios[] = $row;
        }
        echo json_encode($usuarios);
        $stmt->close();


    // Buscar todos 

    } else {
        $stmt = $conn->prepare($select_base);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $usuarios = array();
        while ($row = $resultado->fetch_assoc()) {
            $usuarios[] = $row;
        }
        echo json_encode($usuarios);
        $stmt->close();
    }


// Crear usuario nuevo

} elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    $requeridos = ['nombre', 'apellido', 'correo', 'password', 'id_rol'];
    foreach ($requeridos as $campo) {
        if (!isset($data[$campo]) || trim(strval($data[$campo])) === '') {
            http_response_code(400);
            echo json_encode(["mensaje" => "El campo '$campo' es obligatorio"]);
            $conn->close();
            exit;
        }
    }

    $nombre = trim($data['nombre']);
    $apellido = trim($data['apellido']);
    $correo = trim($data['correo']);
    $password = trim($data['password']);
    $id_rol = intval($data['id_rol']);
    $telefono = isset($data['telefono']) ? trim($data['telefono']) : null;
    $activo = isset($data['activo']) ? (intval($data['activo']) ? 1 : 0) : 1;

    // Validar formato de correo
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El correo no tiene un formato válido"]);
        $conn->close();
        exit;
    }

    // Validar que el correo no esté registrado
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE correo = ?");
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        http_response_code(409);
        echo json_encode(["mensaje" => "Ya existe un usuario con ese correo"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    // Validar que la fk exista
    $stmt = $conn->prepare("SELECT id FROM roles WHERE id = ?");
    $stmt->bind_param("i", $id_rol);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El rol indicado no existe"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $stmt = $conn->prepare("INSERT INTO usuarios (nombre, apellido, correo, password, telefono, id_rol, activo) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssii", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $activo);

    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode([
            "mensaje" => "Usuario creado correctamente",
            "id" => $stmt->insert_id
        ]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al crear el usuario"]);
    }
    $stmt->close();


// Actualizar completamente 

} elseif ($method === 'PUT') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del usuario"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Usuario no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $data = json_decode(file_get_contents("php://input"), true);

    $requeridos = ['nombre', 'apellido', 'correo', 'password', 'id_rol'];
    foreach ($requeridos as $campo) {
        if (!isset($data[$campo]) || trim(strval($data[$campo])) === '') {
            http_response_code(400);
            echo json_encode(["mensaje" => "El campo '$campo' es obligatorio"]);
            $conn->close();
            exit;
        }
    }

    $nombre = trim($data['nombre']);
    $apellido = trim($data['apellido']);
    $correo = trim($data['correo']);
    $password = trim($data['password']);
    $id_rol = intval($data['id_rol']);
    $telefono = isset($data['telefono']) ? trim($data['telefono']) : null;
    $activo = isset($data['activo']) ? (intval($data['activo']) ? 1 : 0) : 1;

    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El correo no tiene un formato válido"]);
        $conn->close();
        exit;
    }

    // Validar que el correo no este en otro usuario , que no sea plagioooo
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE correo = ? AND id != ?");
    $stmt->bind_param("si", $correo, $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        http_response_code(409);
        echo json_encode(["mensaje" => "Ya existe otro usuario con ese correo"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT id FROM roles WHERE id = ?");
    $stmt->bind_param("i", $id_rol);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El rol indicado no existe"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ?, password = ?, telefono = ?, id_rol = ?, activo = ? WHERE id = ?");
    $stmt->bind_param("sssssiii", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $activo, $id);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Usuario actualizado correctamente", "id" => $id]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al actualizar el usuario"]);
    }
    $stmt->close();


// Actualizar únicamente algunas cosas 

} elseif ($method === 'PATCH') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del usuario"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Usuario no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $data = json_decode(file_get_contents("php://input"), true);

    if (!is_array($data) || count($data) === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe enviar al menos un campo para actualizar"]);
        $conn->close();
        exit;
    }

    $campos_permitidos = ['nombre', 'apellido', 'correo', 'password', 'telefono', 'id_rol', 'activo'];
    $sets = [];
    $tipos = "";
    $valores = [];

    // Validaciones específicas

    if (isset($data['correo'])) {
        $correo = trim($data['correo']);
        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(["mensaje" => "El correo no tiene un formato válido"]);
            $conn->close();
            exit;
        }
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE correo = ? AND id != ?");
        $stmt->bind_param("si", $correo, $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            http_response_code(409);
            echo json_encode(["mensaje" => "Ya existe otro usuario con ese correo"]);
            $stmt->close();
            $conn->close();
            exit;
        }
        $stmt->close();
    }

    if (isset($data['id_rol'])) {
        $id_rol_check = intval($data['id_rol']);
        $stmt = $conn->prepare("SELECT id FROM roles WHERE id = ?");
        $stmt->bind_param("i", $id_rol_check);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(["mensaje" => "El rol indicado no existe"]);
            $stmt->close();
            $conn->close();
            exit;
        }
        $stmt->close();
    }

    foreach ($campos_permitidos as $campo) {
        if (isset($data[$campo])) {
            if (trim(strval($data[$campo])) === '' && $campo !== 'activo') {
                http_response_code(400);
                echo json_encode(["mensaje" => "El campo '$campo' no puede estar vacío"]);
                $conn->close();
                exit;
            }
            $sets[] = "$campo = ?";
            if ($campo === 'id_rol') {
                $tipos .= "i";
                $valores[] = intval($data[$campo]);
            } elseif ($campo === 'activo') {
                $tipos .= "i";
                $valores[] = intval($data[$campo]) ? 1 : 0;
            } else {
                $tipos .= "s";
                $valores[] = trim($data[$campo]);
            }
        }
    }

    if (count($sets) === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "No se enviaron campos válidos para actualizar"]);
        $conn->close();
        exit;
    }

    $sql = "UPDATE usuarios SET " . implode(", ", $sets) . " WHERE id = ?";
    $tipos .= "i";
    $valores[] = $id;

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($tipos, ...$valores);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Usuario actualizado correctamente", "id" => $id]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al actualizar el usuario"]);
    }
    $stmt->close();


// Eliminar 

} elseif ($method === 'DELETE') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del usuario"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Usuario no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    // Verificar que el usuario no tenga préstamos asociados, pa saber que dee devolver 
    $stmt = $conn->prepare("SELECT id FROM prestamos WHERE id_usuario = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        http_response_code(409);
        echo json_encode(["mensaje" => "No se puede eliminar el usuario porque tiene préstamos asociados"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Usuario eliminado correctamente"]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al eliminar el usuario"]);
    }
    $stmt->close();


} else {
    http_response_code(405);
    echo json_encode(["mensaje" => "Método no permitido"]);
}

$conn->close();
