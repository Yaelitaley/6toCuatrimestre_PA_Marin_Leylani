<?php
require_once('../../config/connection.php'); 
header("Access-Control-Allow-Origin: *"); 
header("Content-Type: application/json; charset=UTF-8"); 
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {

    // Buscar rol por ID

    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("SELECT id, nombre FROM roles WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            echo json_encode($resultado->fetch_assoc());
        } else {
            http_response_code(404);
            echo json_encode(["mensaje" => "Rol no encontrado"]);
        }
        $stmt->close();


    // Buscar todos los roles

    } else {
        $stmt = $conn->prepare("SELECT id, nombre FROM roles");
        $stmt->execute();
        $resultado = $stmt->get_result();

        $roles = array();
        while ($row = $resultado->fetch_assoc()) {
            $roles[] = $row;
        }
        echo json_encode($roles);
        $stmt->close();
    }


// Crear un rol nuevo

} elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['nombre']) || trim($data['nombre']) === '') {
        http_response_code(400);
        echo json_encode(["mensaje" => "El campo 'nombre' es obligatorio"]);
        $conn->close();
        exit;
    }

    $nombre = trim($data['nombre']);

    // Verificar que no exista pa poder crearlo
    $stmt = $conn->prepare("SELECT id FROM roles WHERE nombre = ?");
    $stmt->bind_param("s", $nombre);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        http_response_code(409);
        echo json_encode(["mensaje" => "Ya existe un rol con ese nombre"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $stmt = $conn->prepare("INSERT INTO roles (nombre) VALUES (?)");
    $stmt->bind_param("s", $nombre);

    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode([
            "mensaje" => "Rol creado correctamente",
            "id" => $stmt->insert_id,
            "nombre" => $nombre
        ]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al crear el rol"]);
    }
    $stmt->close();


// Actualizar completamente 

} elseif ($method === 'PUT') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del rol"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    // Verificar que el rol exista
    $stmt = $conn->prepare("SELECT id FROM roles WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Rol no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['nombre']) || trim($data['nombre']) === '') {
        http_response_code(400);
        echo json_encode(["mensaje" => "El campo 'nombre' es obligatorio"]);
        $conn->close();
        exit;
    }
    $nombre = trim($data['nombre']);

    $stmt = $conn->prepare("UPDATE roles SET nombre = ? WHERE id = ?");
    $stmt->bind_param("si", $nombre, $id);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Rol actualizado correctamente", "id" => $id, "nombre" => $nombre]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al actualizar el rol"]);
    }
    $stmt->close();


// Actualizar únicamente el nombre 

} elseif ($method === 'PATCH') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del rol"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id FROM roles WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Rol no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['nombre']) || trim($data['nombre']) === '') {
        http_response_code(400);
        echo json_encode(["mensaje" => "El campo 'nombre' es obligatorio"]);
        $conn->close();
        exit;
    }
    $nombre = trim($data['nombre']);

    $stmt = $conn->prepare("UPDATE roles SET nombre = ? WHERE id = ?");
    $stmt->bind_param("si", $nombre, $id);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Nombre del rol actualizado correctamente", "id" => $id, "nombre" => $nombre]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al actualizar el nombre del rol"]);
    }
    $stmt->close();


// Eliminar 

} elseif ($method === 'DELETE') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del rol"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id FROM roles WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Rol no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    // Verificar que ningún usuario esté usando este rol por la FK
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE id_rol = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        http_response_code(409);
        echo json_encode(["mensaje" => "No se puede eliminar el rol porque tiene usuarios asignados"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM roles WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Rol eliminado correctamente"]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al eliminar el rol"]);
    }
    $stmt->close();


} else {
    http_response_code(405);
    echo json_encode(["mensaje" => "Método no permitido"]);
}

$conn->close();
