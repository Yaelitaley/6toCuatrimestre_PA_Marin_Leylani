<?php
require_once('../../config/connection.php'); 
header("Access-Control-Allow-Origin: *"); 
header("Content-Type: application/json; charset=UTF-8"); 
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE"); 
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

$select_base = "SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores";


if ($method === 'GET') {

    // Buscar autor por ID
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("$select_base WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            echo json_encode($resultado->fetch_assoc());
        } else {
            http_response_code(404);
            echo json_encode(["mensaje" => "Autor no encontrado"]);
        }
        $stmt->close();


    // Buscar autor por nombre

    } elseif (isset($_GET['nombre'])) {
        $nombre_param = "%" . trim($_GET['nombre']) . "%";
        $stmt = $conn->prepare("$select_base WHERE nombre LIKE ? OR apellido LIKE ?");
        $stmt->bind_param("ss", $nombre_param, $nombre_param);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $autores = array();
        while ($row = $resultado->fetch_assoc()) {
            $autores[] = $row;
        }

        if (count($autores) > 0) {
            echo json_encode($autores);
        } else {
            http_response_code(404);
            echo json_encode(["mensaje" => "No se encontraron autores con ese nombre"]);
        }
        $stmt->close();


    // Buscar autor por nacionalidad

    } elseif (isset($_GET['nacionalidad'])) {
        $nacionalidad_param = "%" . trim($_GET['nacionalidad']) . "%";
        $stmt = $conn->prepare("$select_base WHERE nacionalidad LIKE ?");
        $stmt->bind_param("s", $nacionalidad_param);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $autores = array();
        while ($row = $resultado->fetch_assoc()) {
            $autores[] = $row;
        }

        if (count($autores) > 0) {
            echo json_encode($autores);
        } else {
            http_response_code(404);
            echo json_encode(["mensaje" => "No se encontraron autores de esa nacionalidad"]);
        }
        $stmt->close();


    // Buscar todos los autores

    } else {
        $stmt = $conn->prepare($select_base);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $autores = array();
        while ($row = $resultado->fetch_assoc()) {
            $autores[] = $row;
        }
        echo json_encode($autores);
        $stmt->close();
    }


// Crear un nuevo autor

} elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['nombre']) || trim($data['nombre']) === '' ||
        !isset($data['apellido']) || trim($data['apellido']) === '') {
        http_response_code(400);
        echo json_encode(["mensaje" => "Los campos 'nombre' y 'apellido' son obligatorios"]);
        $conn->close();
        exit;
    }

    $nombre = trim($data['nombre']);
    $apellido = trim($data['apellido']);
    $nacionalidad = isset($data['nacionalidad']) ? trim($data['nacionalidad']) : null;
    $fecha_nacimiento = isset($data['fecha_nacimiento']) ? trim($data['fecha_nacimiento']) : null;

    // Validar formato de fecha si se envía
    if ($fecha_nacimiento !== null && $fecha_nacimiento !== '' && !DateTime::createFromFormat('Y-m-d', $fecha_nacimiento)) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El campo 'fecha_nacimiento' debe tener el formato YYYY-MM-DD"]);
        $conn->close();
        exit;
    }
    if ($fecha_nacimiento === '') {
        $fecha_nacimiento = null;
    }

    $stmt = $conn->prepare("INSERT INTO autores (nombre, apellido, nacionalidad, fecha_nacimiento) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nombre, $apellido, $nacionalidad, $fecha_nacimiento);

    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode([
            "mensaje" => "Autor creado correctamente",
            "id" => $stmt->insert_id
        ]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al crear el autor"]);
    }
    $stmt->close();


// Actualizar completamente un autor

} elseif ($method === 'PUT') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del autor"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id FROM autores WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Autor no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['nombre']) || trim($data['nombre']) === '' ||
        !isset($data['apellido']) || trim($data['apellido']) === '') {
        http_response_code(400);
        echo json_encode(["mensaje" => "Los campos 'nombre' y 'apellido' son obligatorios"]);
        $conn->close();
        exit;
    }

    $nombre = trim($data['nombre']);
    $apellido = trim($data['apellido']);
    $nacionalidad = isset($data['nacionalidad']) ? trim($data['nacionalidad']) : null;
    $fecha_nacimiento = isset($data['fecha_nacimiento']) ? trim($data['fecha_nacimiento']) : null;

    if ($fecha_nacimiento !== null && $fecha_nacimiento !== '' && !DateTime::createFromFormat('Y-m-d', $fecha_nacimiento)) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El campo 'fecha_nacimiento' debe tener el formato YYYY-MM-DD"]);
        $conn->close();
        exit;
    }
    if ($fecha_nacimiento === '') {
        $fecha_nacimiento = null;
    }

    $stmt = $conn->prepare("UPDATE autores SET nombre = ?, apellido = ?, nacionalidad = ?, fecha_nacimiento = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $nombre, $apellido, $nacionalidad, $fecha_nacimiento, $id);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Autor actualizado correctamente", "id" => $id]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al actualizar el autor"]);
    }
    $stmt->close();


// Actualizar algunos campos del autor

} elseif ($method === 'PATCH') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del autor"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id FROM autores WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Autor no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $data = json_decode(file_get_contents("php://input"), true);

    if (!is_array($data) || count($data) === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe enviar al menos un campo para actualizar"]);
        $conn->close();
        exit;
    }

    $campos_permitidos = ['nombre', 'apellido', 'nacionalidad', 'fecha_nacimiento'];
    $sets = [];
    $tipos = "";
    $valores = [];

    if (isset($data['fecha_nacimiento']) && trim($data['fecha_nacimiento']) !== '' &&
        !DateTime::createFromFormat('Y-m-d', trim($data['fecha_nacimiento']))) {
        http_response_code(400);
        echo json_encode(["mensaje" => "El campo 'fecha_nacimiento' debe tener el formato YYYY-MM-DD"]);
        $conn->close();
        exit;
    }

    foreach ($campos_permitidos as $campo) {
        if (isset($data[$campo])) {
            $valor = trim($data[$campo]);
            if ($valor === '' && ($campo === 'nombre' || $campo === 'apellido')) {
                http_response_code(400);
                echo json_encode(["mensaje" => "El campo '$campo' no puede estar vacío"]);
                $conn->close();
                exit;
            }
            $sets[] = "$campo = ?";
            $tipos .= "s";
            $valores[] = $valor === '' ? null : $valor;
        }
    }

    if (count($sets) === 0) {
        http_response_code(400);
        echo json_encode(["mensaje" => "No se enviaron campos válidos para actualizar"]);
        $conn->close();
        exit;
    }

    $sql = "UPDATE autores SET " . implode(", ", $sets) . " WHERE id = ?";
    $tipos .= "i";
    $valores[] = $id;

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($tipos, ...$valores);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Autor actualizado correctamente", "id" => $id]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al actualizar el autor"]);
    }
    $stmt->close();


// Eliminar autorcito

} elseif ($method === 'DELETE') {
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debe indicar el id del autor"]);
        $conn->close();
        exit;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT id FROM autores WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["mensaje" => "Autor no encontrado"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    // Verificar que el autor no este con algun libro
    $stmt = $conn->prepare("SELECT id_libro FROM libro_autor WHERE id_autor = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        http_response_code(409);
        echo json_encode(["mensaje" => "No se puede eliminar el autor porque tiene libros asociados"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM autores WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Autor eliminado correctamente"]);
    } else {
        http_response_code(500);
        echo json_encode(["mensaje" => "Error al eliminar el autor"]);
    }
    $stmt->close();


} else {
    http_response_code(405);
    echo json_encode(["mensaje" => "Método no permitido"]);
}

$conn->close();
