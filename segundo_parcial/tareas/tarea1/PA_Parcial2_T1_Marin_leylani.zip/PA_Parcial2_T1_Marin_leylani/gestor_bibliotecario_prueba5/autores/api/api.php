<?php
require_once('../../config/connection.php'); 
header("Access-Control-Allow-Origin: *"); 
header("Content-Type: application/json; charset=UTF-8"); 
header("Access-Control-Allow-Methods: GET"); 
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'GET') {
    http_response_code(405);
    echo json_encode(["mensaje" => "Método no permitido. Esta API solo acepta GET"]);
    $conn->close();
    exit;
}

$select_base = "SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores";


// Buscar autor por ID
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("$select_base WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        echo json_encode($resultado->fetch_assoc());
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "Autor no encontrado"]);
    }
    $stmt->close();


// Buscar autor por nombre

} elseif (isset($_GET['nombre'])) {
    $nombre_param = "%" . trim($_GET['nombre']) . "%";
    $stmt = $conn->prepare("$select_base WHERE nombre LIKE ? OR apellido LIKE ?");
    $stmt->bind_param("ss", $nombre_param, $nombre_param);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $autores = array();
    while ($row = $resultado->fetch_assoc()) {
        $autores[] = $row;
    }

    if (count($autores) > 0) {
        echo json_encode($autores);
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "No se encontraron autores con ese nombre"]);
    }
    $stmt->close();


// Buscar autor por nacionalidad

} elseif (isset($_GET['nacionalidad'])) {
    $nacionalidad_param = "%" . trim($_GET['nacionalidad']) . "%";
    $stmt = $conn->prepare("$select_base WHERE nacionalidad LIKE ?");
    $stmt->bind_param("s", $nacionalidad_param);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $autores = array();
    while ($row = $resultado->fetch_assoc()) {
        $autores[] = $row;
    }

    if (count($autores) > 0) {
        echo json_encode($autores);
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "No se encontraron autores de esa nacionalidad"]);
    }
    $stmt->close();


// Buscar todos los autores

} else {
    $stmt = $conn->prepare($select_base);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $autores = array();
    while ($row = $resultado->fetch_assoc()) {
        $autores[] = $row;
    }
    echo json_encode($autores);
    $stmt->close();
}

$conn->close();
