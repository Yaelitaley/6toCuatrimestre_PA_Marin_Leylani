<?php
require_once('../../config/connection.php'); 
header("Access-Control-Allow-Origin: *"); 
header("Content-Type: application/json; charset=UTF-8"); 
header("Access-Control-Allow-Methods: GET"); 
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");


$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'GET') {
    http_response_code(405);
    echo json_encode(["mensaje" => "Método no permitido. Esta API solo acepta GET"]);
    $conn->close();
    exit;
}


// Buscar categoría por ID

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT id, nombre, descripcion FROM categorias WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $categoria = $resultado->fetch_assoc();
        echo json_encode($categoria);
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "Categoría no encontrada"]);
    }
    $stmt->close();


// Buscar categoría por nombre

} elseif (isset($_GET['nombre'])) {
    $nombre = trim($_GET['nombre']);
    $nombre_param = "%$nombre%";
    $stmt = $conn->prepare("SELECT id, nombre, descripcion FROM categorias WHERE nombre LIKE ?");
    $stmt->bind_param("s", $nombre_param);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $categorias = array();
    while ($row = $resultado->fetch_assoc()) {
        $categorias[] = $row;
    }

    if (count($categorias) > 0) {
        echo json_encode($categorias);
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "No se encontraron categorías con ese nombre"]);
    }
    $stmt->close();


// Buscar todas las categorías

} else {
    $stmt = $conn->prepare("SELECT id, nombre, descripcion FROM categorias");
    $stmt->execute();
    $resultado = $stmt->get_result();

    $categorias = array();
    while ($row = $resultado->fetch_assoc()) {
        $categorias[] = $row;
    }
    echo json_encode($categorias);
    $stmt->close();
}

$conn->close();
