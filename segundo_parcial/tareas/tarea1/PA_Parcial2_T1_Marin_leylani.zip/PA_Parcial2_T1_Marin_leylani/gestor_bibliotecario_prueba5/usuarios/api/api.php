<?php
require_once('../../config/connection.php'); 
header("Access-Control-Allow-Origin: *"); 
header("Content-Type: application/json; charset=UTF-8"); 
header("Access-Control-Allow-Methods: GET"); 
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'GET') {
    http_response_code(405);
    echo json_encode(["mensaje" => "Método no permitido. Esta API solo acepta GET"]);
    $conn->close();
    exit;
}

$select_base = "SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios";



// Buscar usuario por ID

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("$select_base WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        echo json_encode($resultado->fetch_assoc());
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "Usuario no encontrado"]);
    }
    $stmt->close();


// Buscar usuario por nombre

} elseif (isset($_GET['nombre'])) {
    $nombre_param = "%" . trim($_GET['nombre']) . "%";
    $stmt = $conn->prepare("$select_base WHERE nombre LIKE ?");
    $stmt->bind_param("s", $nombre_param);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $usuarios = array();
    while ($row = $resultado->fetch_assoc()) {
        $usuarios[] = $row;
    }

    if (count($usuarios) > 0) {
        echo json_encode($usuarios);
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "No se encontraron usuarios con ese nombre"]);
    }
    $stmt->close();


// Buscar usuario por correo

} elseif (isset($_GET['correo'])) {
    $correo_param = trim($_GET['correo']);
    $stmt = $conn->prepare("$select_base WHERE correo = ?");
    $stmt->bind_param("s", $correo_param);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        echo json_encode($resultado->fetch_assoc());
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "No se encontró un usuario con ese correo"]);
    }
    $stmt->close();


// Usuarios activos

} elseif (isset($_GET['activo'])) {
    $stmt = $conn->prepare("$select_base WHERE activo = 1");
    $stmt->execute();
    $resultado = $stmt->get_result();

    $usuarios = array();
    while ($row = $resultado->fetch_assoc()) {
        $usuarios[] = $row;
    }
    echo json_encode($usuarios);
    $stmt->close();


// Buscar todos los usuarios

} else {
    $stmt = $conn->prepare($select_base);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $usuarios = array();
    while ($row = $resultado->fetch_assoc()) {
        $usuarios[] = $row;
    }
    echo json_encode($usuarios);
    $stmt->close();
}

$conn->close();
