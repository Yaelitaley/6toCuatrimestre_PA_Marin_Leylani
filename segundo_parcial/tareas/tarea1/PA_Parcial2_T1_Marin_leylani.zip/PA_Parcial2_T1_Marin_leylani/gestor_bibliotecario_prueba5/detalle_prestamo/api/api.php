<?php
require_once('../../config/connection.php'); 
header("Access-Control-Allow-Origin: *"); 
header("Content-Type: application/json; charset=UTF-8"); 
header("Access-Control-Allow-Methods: GET"); 
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'GET') {
    http_response_code(405);
    echo json_encode(["mensaje" => "Método no permitido. Esta API solo acepta GET"]);
    $conn->close();
    exit;
}

$select_base = "SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo";


// Buscar registro por ID

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("$select_base WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        echo json_encode($resultado->fetch_assoc());
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "Registro no encontrado"]);
    }
    $stmt->close();


// Buscar detalle por préstamo

} elseif (isset($_GET['id_prestamo'])) {
    $id_prestamo = intval($_GET['id_prestamo']);
    $stmt = $conn->prepare("$select_base WHERE id_prestamo = ?");
    $stmt->bind_param("i", $id_prestamo);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $detalles = array();
    while ($row = $resultado->fetch_assoc()) {
        $detalles[] = $row;
    }

    if (count($detalles) > 0) {
        echo json_encode($detalles);
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "No se encontraron registros para ese préstamo"]);
    }
    $stmt->close();


// Buscar detalle por libro

} elseif (isset($_GET['id_libro'])) {
    $id_libro = intval($_GET['id_libro']);
    $stmt = $conn->prepare("$select_base WHERE id_libro = ?");
    $stmt->bind_param("i", $id_libro);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $detalles = array();
    while ($row = $resultado->fetch_assoc()) {
        $detalles[] = $row;
    }

    if (count($detalles) > 0) {
        echo json_encode($detalles);
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "No se encontraron registros para ese libro"]);
    }
    $stmt->close();


// Buscar todos los registros

} else {
    $stmt = $conn->prepare($select_base);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $detalles = array();
    while ($row = $resultado->fetch_assoc()) {
        $detalles[] = $row;
    }
    echo json_encode($detalles);
    $stmt->close();
}

$conn->close();
