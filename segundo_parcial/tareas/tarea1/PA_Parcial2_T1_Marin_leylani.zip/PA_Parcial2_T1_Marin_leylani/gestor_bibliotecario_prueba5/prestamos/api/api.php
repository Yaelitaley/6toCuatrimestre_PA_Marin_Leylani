<?php
require_once('../../config/connection.php'); 
header("Access-Control-Allow-Origin: *"); 
header("Content-Type: application/json; charset=UTF-8"); 
header("Access-Control-Allow-Methods: GET"); 
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'GET') {
    http_response_code(405);
    echo json_encode(["mensaje" => "Método no permitido. Esta API solo acepta GET"]);
    $conn->close();
    exit;
}

$select_base = "SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos";


// Buscar préstamo por ID

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("$select_base WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        echo json_encode($resultado->fetch_assoc());
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "Préstamo no encontrado"]);
    }
    $stmt->close();


// Buscar préstamos por usuario

} elseif (isset($_GET['id_usuario'])) {
    $id_usuario = intval($_GET['id_usuario']);
    $stmt = $conn->prepare("$select_base WHERE id_usuario = ?");
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $prestamos = array();
    while ($row = $resultado->fetch_assoc()) {
        $prestamos[] = $row;
    }

    if (count($prestamos) > 0) {
        echo json_encode($prestamos);
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "No se encontraron préstamos para ese usuario"]);
    }
    $stmt->close();


// Buscar préstamos por estado

} elseif (isset($_GET['estado'])) {
    $estado = trim($_GET['estado']);
    $stmt = $conn->prepare("$select_base WHERE estado = ?");
    $stmt->bind_param("s", $estado);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $prestamos = array();
    while ($row = $resultado->fetch_assoc()) {
        $prestamos[] = $row;
    }

    if (count($prestamos) > 0) {
        echo json_encode($prestamos);
    } else {
        http_response_code(404);
        echo json_encode(["mensaje" => "No se encontraron préstamos con ese estado"]);
    }
    $stmt->close();


// Préstamos vencidos: siguen como "prestado" pero la fecha ya paso

} elseif (isset($_GET['atrasados'])) {
    $stmt = $conn->prepare("$select_base WHERE estado = 'prestado' AND fecha_devolucion < CURDATE()");
    $stmt->execute();
    $resultado = $stmt->get_result();

    $prestamos = array();
    while ($row = $resultado->fetch_assoc()) {
        $prestamos[] = $row;
    }
    echo json_encode($prestamos);
    $stmt->close();


// Buscar todos los préstamos

} else {
    $stmt = $conn->prepare($select_base);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $prestamos = array();
    while ($row = $resultado->fetch_assoc()) {
        $prestamos[] = $row;
    }
    echo json_encode($prestamos);
    $stmt->close();
}

$conn->close();
