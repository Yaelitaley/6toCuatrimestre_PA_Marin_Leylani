<?php
    require_once "../config/connection.php";
    header("Content-Type: application/json; charset=UTF-8"); 

    // agarramos el valor , o el nombre que se haya puesto en el input de busqueda, si no se escribe nada queda con cadena vacia o texto vacio 
    $nombre = isset($_GET["nombre"]) ? trim($_GET["nombre"]) : ""; // Si el parámetro "nombre" existe lo tomamos y le quitamos los espacios en blanco que puedan afectar la busqueda


    //con esto preparo mi consulta para buscar en la ase de datos , segun lo que contenga  mi tabla 
    $stmt = $conn->prepare("SELECT id, nombre, descripcion FROM categorias WHERE nombre LIKE ? ORDER BY nombre ASC");
    $busqueda = "%" . $nombre . "%"; // coloco el porcentaje para que busque cualquier coincidencia que contenga el nombre ingresado 
    $stmt->bind_param("s", $busqueda); // vinvulo el parametro de busqueda a la consulta que prepare, la "s" me indica quees un tipo de datos String 
    $stmt->execute(); // Ejecutamos la consulta preparada.
    $resultado = $stmt->get_result(); // Obtenemos el resultado de la consulta.

    $categorias = array(); // Creamos un arreglo vacío en el que iremos guardando cada categoría encontrada.
    while ($row = $resultado->fetch_assoc()) { // Recorremos fila por fila el resultado obtenido.
        $categorias[] = $row; // Agregamos la fila actual, lo va como añadiendo al arreglo de categorías.
    }

    echo json_encode($categorias); 

    $stmt->close(); // Cerramos la consulta preparada para liberar recursos.
    $conn->close(); // Cerramos la conexión a la base de datos.
?>
