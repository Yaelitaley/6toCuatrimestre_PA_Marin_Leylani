<?php
require_once('../../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];
//BASICAMENTE LOS METODOS SE REPITEN 
switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                echo json_encode($resultado->fetch_assoc());
            } else {
                echo json_encode(["mensaje" => "Autor no encontrado"]);
            }
            $stmt->close();

        } elseif (isset($_GET['nombre'])) {
            $nombre = "%" . trim($_GET['nombre']) . "%";
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE nombre LIKE ? OR apellido LIKE ?");
            $stmt->bind_param("ss", $nombre, $nombre);
            $stmt->execute();
            $resultado = $stmt->get_result();

            $autores = [];
            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }
            echo json_encode(count($autores) > 0 ? $autores : ["mensaje" => "Autor no encontrado"]);
            $stmt->close();

        } elseif (isset($_GET['nacionalidad'])) {
            $nacionalidad = trim($_GET['nacionalidad']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE nacionalidad LIKE ?");
            $param = "%$nacionalidad%";
            $stmt->bind_param("s", $param);
            $stmt->execute();
            $resultado = $stmt->get_result();

            $autores = [];
            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }
            echo json_encode(count($autores) > 0 ? $autores : ["mensaje" => "Autor no encontrado"]);
            $stmt->close();

        } elseif (isset($_GET['nacido_despues'])) {
            $fecha = trim($_GET['nacido_despues']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE fecha_nacimiento > ?");
            $stmt->bind_param("s", $fecha);
            $stmt->execute();
            $resultado = $stmt->get_result();

            $autores = [];
            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }
            echo json_encode($autores);
            $stmt->close();

        } else {
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores");
            $stmt->execute();
            $resultado = $stmt->get_result();

            $autores = [];
            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }
            echo json_encode($autores);
            $stmt->close();
        }
        $conn->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(["mensaje" => "Método no permitido. Esta API solo acepta GET"]);
        break;
}
