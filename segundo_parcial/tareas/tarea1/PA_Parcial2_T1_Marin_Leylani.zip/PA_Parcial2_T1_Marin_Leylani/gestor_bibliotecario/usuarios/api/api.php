<?php
require_once('../../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

//esta parte me ayuda a no mostrar la columna de contraseña , para que no cualquiera lo pueda ver 
$columnas = "id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro";

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) { //volvemos a confirmar que manden id 
            $id = intval($_GET['id']);//convierte en integer , numero entero pues 
            $stmt = $conn->prepare("SELECT $columnas FROM usuarios WHERE id = ?"); //verificamos la tabla en la bd 
            $stmt->bind_param("i", $id); //asigno valor de integer , porque es numero el valor 
            $stmt->execute(); //ejecuta la consulta , anteriorimente preparada 
            $resultado = $stmt->get_result(); //muestra resultado 

            //si hay coincidencia , manda la respuesta en JSON 
            if ($resultado->num_rows > 0) {
                echo json_encode($resultado->fetch_assoc());
            } else {
                //si no , muestra mensaje de error 
                echo json_encode(["mensaje" => "Usuario no encontrado"]);
            }
            $stmt->close();

        } elseif (isset($_GET['correo'])) { //ahora vemos que nos mnaden correo 
            $correo = trim($_GET['correo']); // quito espacios en inicio y final 
            $stmt = $conn->prepare("SELECT $columnas FROM usuarios WHERE correo = ?"); //aqui cambio un poco , sgeun investigue en correo se debe usar "=" para que coincida exactamente , no un poco , porque si no hay errores 
            $stmt->bind_param("s", $correo); //mi valor es string , no int osea es texto , no numero 
            $stmt->execute(); //ejecutamos consulta 
            $resultado = $stmt->get_result(); 

            //aqui no necesto arreglo , porque el correo es unico , es decir que no debe de guardar varios 
            if ($resultado->num_rows > 0) {
                echo json_encode($resultado->fetch_assoc());
            } else {
                //si el correo , no coincide , manda mensaje de error 
                echo json_encode(["mensaje" => "Usuario no encontrado"]);
            }
            $stmt->close();

        } elseif (isset($_GET['nombre'])) {
            $nombre = "%" . trim($_GET['nombre']) . "%"; 
            $stmt = $conn->prepare("SELECT $columnas FROM usuarios WHERE nombre LIKE ?");
            $stmt->bind_param("s", $nombre);
            $stmt->execute();
            $resultado = $stmt->get_result();

            $usuarios = [];
            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }
            echo json_encode(count($usuarios) > 0 ? $usuarios : ["mensaje" => "Usuario no encontrado"]);
            $stmt->close();

        } elseif (isset($_GET['activo'])) {
            $activo = intval($_GET['activo']);
            $stmt = $conn->prepare("SELECT $columnas FROM usuarios WHERE activo = ?");
            $stmt->bind_param("i", $activo);
            $stmt->execute();
            $resultado = $stmt->get_result();

            $usuarios = [];
            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }
            echo json_encode($usuarios);
            $stmt->close();

        } else {
            $stmt = $conn->prepare("SELECT $columnas FROM usuarios");
            $stmt->execute();
            $resultado = $stmt->get_result();

            $usuarios = [];
            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }
            echo json_encode($usuarios);
            $stmt->close();
        }
        $conn->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(["mensaje" => "Método no permitido. Esta API solo acepta GET"]);
        break;
}
