<?php
require_once('../../config/connection.php'); // Importa la conexión a la base de datos
header("Access-Control-Allow-Origin: *"); // Permite que cualquier origen pueda acceder a esta API, sin importar su dominio. Esto nos va a ayudar a prevenir los famosos problemas de CORS (Cross-Origin Resource Sharing). ¿Qué es CORS? CORS es una política de seguridad implementada por los navegadores web para restringir las solicitudes HTTP que se puedan hacer a un dominio diferente al que sirvió la página web.
header("Content-Type: application/json; charset=UTF-8"); // Esta cabecer, indica el tipo de contenido que va a ser devuelto por esta API, para este ejemplo, va ser en formato JSON. Además, también especificamos la encodificación de caracteres, en este caso UTF-8.
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE"); // Esta cabecera especifica los métodos HTTP que esta API va a aceptar. Es una cabecera importante para temas de seguridad. ¿Qué ocurre si un cliente intenta hacer una solicitud no permitida? En este caso, el servidor responderá con un código de estado HTTP 405 Method Not Allowed, indicando que el método utilizado en la solicitud no está permitido para el recurso solicitado.
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"); // Esta cabecera especifica los encabezados HTTP que se permitirán en las solicitudes o peticiones recibidas por esta API. Es decir, si un cliente hace una solicitud a esta API, y envía una cabecer no permitida, el servidor responderá con un código de estado HTTP 400 Bad Request, indicando que la solicitud no se pudo procesar debido a encabezados no permitidos.


$method = $_SERVER['REQUEST_METHOD']; 



switch ($method) { // Utilizamos la condicional switch-case para evaluar el valor de la variable $method. NOTA: Técnicamente igual podríamos utilizar una estructura if-else, sin embargo el switch-case es un método más limpio
    case 'GET':
        //POR ID
        $columnas = "id, titulo, isbn, anio_publicacion, editorial, cantidad, disponibles, id_categoria, fecha_registro";
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT $columnas FROM libros WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                echo json_encode($resultado->fetch_assoc());
            } else {
                echo json_encode(array("mensaje" => "Libro no encontrado"));
            }
            $stmt->close();
            $conn->close();
           

            // TODO ESTE CODIGO LO HICE EN CLASE 
            // ME SIRVE PARA MI TAREA QUE SE ENTREGA EL DOMINGO 



          //POR TITULO

        } elseif (isset($_GET['titulo'])) {
            $titulo = trim($_GET['titulo']);
            $stmt = $conn->prepare("SELECT $columnas FROM libros WHERE titulo LIKE ?");
            $titulo_param = "%$titulo%";
            $stmt->bind_param("s", $titulo_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();
            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }
            echo json_encode(count($libros) > 0 ? $libros : array("mensaje" => "Libro no encontrado"));
            $stmt->close();
            $conn->close();

            //AÑO DE PUBLICACION
        } elseif (isset($_GET['anio_publicacion'])) {
            $anio = intval($_GET['anio_publicacion']);
            $stmt = $conn->prepare("SELECT $columnas FROM libros WHERE anio_publicacion = ?");
            $stmt->bind_param("i", $anio);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();
            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }
            echo json_encode(count($libros) > 0 ? $libros : array("mensaje" => "Libro no encontrado"));
            $stmt->close();
            $conn->close();


            //POR CATEGORIA
        } elseif (isset($_GET['id_categoria'])) {
            $id_categoria = intval($_GET['id_categoria']);
            $stmt = $conn->prepare("SELECT $columnas FROM libros WHERE id_categoria = ?");
            $stmt->bind_param("i", $id_categoria);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();
            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }
            echo json_encode($libros);
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['editorial'])) {
          

        //POR EDITORIAL 
            $editorial = trim($_GET['editorial']);
            $stmt = $conn->prepare("SELECT $columnas FROM libros WHERE editorial LIKE ?");
            $editorial_param = "%$editorial%";
            $stmt->bind_param("s", $editorial_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();
            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }
            echo json_encode($libros);
            $stmt->close();
            $conn->close();


            //LIBROS DISPONIBLES 
        } elseif (isset($_GET['disponibles'])) {
            $stmt = $conn->prepare("SELECT $columnas FROM libros WHERE disponibles > 0");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();
            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }
            echo json_encode($libros);
            $stmt->close();
            $conn->close();
        } else {
    

        //TODOS LOS LIBROS 
            $stmt = $conn->prepare("SELECT $columnas FROM libros");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();
            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }
            echo json_encode($libros);
            $stmt->close();
            $conn->close();
        }
        break;









    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true); // Aquí lo que estoy haciendo es crear una variable llamada $data, y esta variable contiene la decodificación de los datos JSON, que se realiza mediante el método json_decode(). ¿A qué se refiere o para qué me sirve la decodificación? Recuerda que el cliente envía los datos en formato JSON, entonces para poder trabajarlos en nuestro código PHP necesitamos convertirlos de formato JSON a un formato que PHP pueda entender, en este caso usaremos un arreglo asociativo. El método json_decode() hace tal cual eso, convierte una cadena JSON en una estructura de datos de PHP. El parámetro file_get_contents("php://input") se utiliza para leer el cuerpo de la solicitud HTTP, y el parámetro true, indica que el resultado debe ser un arreglo asociativo.

        $titulo            = trim($data['titulo'] ?? "");
        $isbn              = trim($data['isbn'] ?? "");
        $anio_publicacion  = trim($data['anio_publicacion'] ?? "");
        $editorial         = trim($data['editorial'] ?? "");
        $cantidad          = trim($data['cantidad'] ?? "");
        $disponibles       = trim($data['disponibles'] ?? "");
        $id_categoria      = trim($data['id_categoria'] ?? "");

        if (
            !empty($titulo) &&
            !empty($isbn) &&
            !empty($anio_publicacion) &&
            !empty($editorial) &&
            !empty($cantidad) &&
            !empty($disponibles) &&
            !empty($id_categoria)
        ) {

            $stmt = $conn->prepare(
                "INSERT INTO libros (
                    titulo,
                    isbn,
                    anio_publicacion,
                    editorial,
                    cantidad,
                    disponibles,
                    id_categoria
                ) VALUES (?, ?, ?, ?, ?, ?, ?)"
            );

            $stmt->bind_param(
                "sssssii",
                $titulo,
                $isbn,
                $anio_publicacion,
                $editorial,
                $cantidad,
                $disponibles,
                $id_categoria
            );

            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode([
                    "mensaje" => "Libro creado exitosamente"
                ]);
            } else {
                echo json_encode([
                    "mensaje" => "Error al crear el libro"
                ]);
            }

            $stmt->close();
            $conn->close();

        } else {

            echo json_encode([
                "mensaje" => "Todos los campos son obligatorios"
            ]);

        }

        break;







    case 'PUT':
         if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode([
                "mensaje" => "Debe enviar el id del libro a actualizar (ej. api.php?id=1)"
            ]);
            break;
        }

        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true); // Igual que en POST, decodificamos el JSON enviado en el cuerpo de la solicitud a un arreglo asociativo de PHP

        $titulo            = trim($data['titulo'] ?? "");
        $isbn              = trim($data['isbn'] ?? "");
        $anio_publicacion  = trim($data['anio_publicacion'] ?? "");
        $editorial         = trim($data['editorial'] ?? "");
        $cantidad          = trim($data['cantidad'] ?? "");
        $disponibles       = trim($data['disponibles'] ?? "");
        $id_categoria      = trim($data['id_categoria'] ?? "");

        if (
            !empty($titulo) &&
            !empty($isbn) &&
            !empty($anio_publicacion) &&
            !empty($editorial) &&
            !empty($cantidad) &&
            !empty($disponibles) &&
            !empty($id_categoria)
        ) {

            $stmt = $conn->prepare(
                "UPDATE libros SET
                    titulo = ?,
                    isbn = ?,
                    anio_publicacion = ?,
                    editorial = ?,
                    cantidad = ?,
                    disponibles = ?,
                    id_categoria = ?
                WHERE id = ?"
            );

            $stmt->bind_param(
                "sssssiii",
                $titulo,
                $isbn,
                $anio_publicacion,
                $editorial,
                $cantidad,
                $disponibles,
                $id_categoria,
                $id
            );

            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    http_response_code(200);
                    echo json_encode([
                        "mensaje" => "Libro actualizado exitosamente"
                    ]);
                } else {
                    http_response_code(404);
                    echo json_encode([
                        "mensaje" => "Libro no encontrado o sin cambios"
                    ]);
                }
            } else {
                http_response_code(500);
                echo json_encode([
                    "mensaje" => "Error al actualizar el libro"
                ]);
            }

            $stmt->close();
            $conn->close();

        } else {

            http_response_code(400);
            echo json_encode([
                "mensaje" => "Todos los campos son obligatorios para una actualización completa (PUT)"
            ]);

        }
        break;






    case 'PATCH':
         if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode([
                "mensaje" => "Debe enviar el id del libro a actualizar (ej. api.php?id=1)"
            ]);
            break;
        }

        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);

        $campos = array();
        $tipos = "";
        $valores = array();

        $columnas_permitidas = array(
            "titulo"           => "s",
            "isbn"             => "s",
            "anio_publicacion" => "s",
            "editorial"        => "s",
            "cantidad"         => "i",
            "disponibles"      => "i",
            "id_categoria"     => "i",
        );

        foreach ($columnas_permitidas as $columna => $tipo) {
            if (isset($data[$columna]) && trim($data[$columna]) !== "") {
                $campos[]  = "$columna = ?";
                $tipos    .= $tipo;
                $valores[] = trim($data[$columna]);
            }
        }

        if (count($campos) > 0) {

            $sql = "UPDATE libros SET " . implode(", ", $campos) . " WHERE id = ?";
            $tipos .= "i";
            $valores[] = $id;

            $stmt = $conn->prepare($sql);
            $stmt->bind_param($tipos, ...$valores); 

            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    http_response_code(200);
                    echo json_encode([
                        "mensaje" => "Libro actualizado parcialmente con éxito"
                    ]);
                } else {
                    http_response_code(404);
                    echo json_encode([
                        "mensaje" => "Libro no encontrado o sin cambios"
                    ]);
                }
            } else {
                http_response_code(500);
                echo json_encode([
                    "mensaje" => "Error al actualizar el libro"
                ]);
            }

            $stmt->close();
            $conn->close();

        } else {

            http_response_code(400);
            echo json_encode([
                "mensaje" => "Debe enviar al menos un campo para actualizar"
            ]);

        }

        break;


    case 'DELETE':
        if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode(["mensaje" => "Debe enviar el id del libro a eliminar"]);
            break;
        }
        $id = intval($_GET['id']);

        $stmt = $conn->prepare("DELETE FROM libros WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                http_response_code(200);
                echo json_encode(["mensaje" => "Libro eliminado correctamente"]);
            } else {
                http_response_code(404);
                echo json_encode(["mensaje" => "Libro no encontrado"]);
            }
        } else {
            http_response_code(500);
            echo json_encode(["mensaje" => "Error al eliminar el libro"]);
        }

        $stmt->close();
        $conn->close();
        break;
}
