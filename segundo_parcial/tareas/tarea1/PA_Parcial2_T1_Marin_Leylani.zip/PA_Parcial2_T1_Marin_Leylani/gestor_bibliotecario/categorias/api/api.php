<?php
require_once('../../config/connection.php'); //conexion con la bd 
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET"); //vuelvo a declarar solo get , cuando me lo pidan aqui van los demas (put,patch,delete )
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) { //verifica que me mande un id 
            $id = intval($_GET['id']); //convierto el id que me manden a entero , pa que no me marque errores 
            $stmt = $conn->prepare("SELECT id, nombre, descripcion FROM categorias WHERE id = ?"); //preguntamos en la tabla "categorias" , con los campos que contiene mi tabla 
            $stmt->bind_param("i", $id); //asocio mi valor otravez , como con roles (porque ese hice rpimero)
            $stmt->execute(); //ejecuta mi consulta anterior 
            $resultado = $stmt->get_result();//muestra los resultados de la consulta que hice 
            
            //si encuentra alguna fila , lo regresa en formato JSON 
            if ($resultado->num_rows > 0) {
                echo json_encode($resultado->fetch_assoc());
            } else {
                //si no , marca "error" que en realidad no muestra cual es el error es solo una marca que le estoy poniendo 
                // (si busca posteriormente mostrar un mensaje que marque el error este no es el codigo) y manda mensaje de que no lo encontro 
                echo json_encode(array("mensaje" => "Categoría no encontrada"));
            }
            $stmt->close();

        } elseif (isset($_GET['nombre'])) { //aqui cambiamos , buscamos por nombre 
            $nombre = trim($_GET['nombre']); //quitamos espacios la inicio y final del nomre 
            $nombre_param = "%$nombre%"; 
            // Agrego los símbolos % antes y después: esto le dice a MySQL "busca este texto
             // en cualquier parte del campo", no solo si coincide exacto (esto todavia no lo entiendo al 100 INVESTIGAR BIEN)
            $stmt = $conn->prepare("SELECT id, nombre, descripcion FROM categorias WHERE nombre LIKE ?"); //preguntamos si esta, con consulta preparada 
            $stmt->bind_param("s", $nombre_param); //ahora asociamos a STRING porque es texto 
            $stmt->execute();//ejecutamos consulta
            $resultado = $stmt->get_result(); //guardamos tantito los resultados 
            $categorias = array(); //hice un array porque como es por nombre puede regresar varios , no solo uno
            //recorre cada fila , y las coincidencias las va a ir agregando al arreglo que hice 
            while ($row = $resultado->fetch_assoc()) {
                $categorias[] = $row;
            }
            //si no coincide con ninguna , muestra mensaje de que no esta 
            echo json_encode(count($categorias) > 0 ? $categorias : array("mensaje" => "Categoría no encontrada"));
            $stmt->close();

        } else {
            $stmt = $conn->prepare("SELECT id, nombre, descripcion FROM categorias"); //preaparamos consulta en la tabla de categorias 
            $stmt->execute(); //ejecutamos 
            $resultado = $stmt->get_result();// volvemos a guardar resultados 
            $categorias = array();//otro arreglo 
            //recorre fila por fila buscandoy agregandolo
            while ($row = $resultado->fetch_assoc()) {
                $categorias[] = $row;
            }
            //muestro los resultados en formato JSON 
            echo json_encode($categorias);
            $stmt->close();
        }
        $conn->close();
        break;

    default:
    //mensaje pr default si todo lo anterior esta mal , osea que no men dieron un get 
        http_response_code(405);
        echo json_encode(["mensaje" => "Método no permitido. Esta API solo acepta GET"]);
        break;
}
