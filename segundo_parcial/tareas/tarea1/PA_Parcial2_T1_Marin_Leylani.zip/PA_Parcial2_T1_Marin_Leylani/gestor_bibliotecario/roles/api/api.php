<?php
require_once('../../config/connection.php'); //mi conexion a mysql con mi archivo (connection.php)
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET"); //aqui solo estoy declarando get , si el maestro pide agregar mas , saqui los tengo que declarar (debo separar con "," si no marca error)
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD']; 

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) { //esto me ayuda a revisar si mandaron un id que buscar 
            $id = intval($_GET['id']); //convertimos el numero a entero , para evitar errores 
            $stmt = $conn->prepare("SELECT id, nombre FROM roles WHERE id = ?");
            $stmt->bind_param("i", $id); //asocio mi valor al "i" por el integer , porque es numero mi valor 
            $stmt->execute(); //hace la consulta en la base de datos 
            $resultado = $stmt->get_result(); //resultado de lo de arriba 

            // si encuentra una fila tan si quiera , regresa la respuesta en JSON
            if ($resultado->num_rows > 0) {
                echo json_encode($resultado->fetch_assoc());
            } else {
                //si no encuentra nada , manda mensaje de error 
                echo json_encode(["mensaje" => "Rol no encontrado"]);
            }
            // cierre de stmt (statement)
            $stmt->close();
        } else {
            //en caso de que no manden ningun id , esto va a mostrar todos los registros 
            $stmt = $conn->prepare("SELECT id, nombre FROM roles");
            $stmt->execute();
            $resultado = $stmt->get_result();

            //arreglo vacio para ir guardando cada fila , para mostrarla 
            $roles = [];
            // recorre una por una y guarda el resultado en el arreglo de arriba 
            while ($row = $resultado->fetch_assoc()) {
                $roles[] = $row;
            }
            //convierto el arreglo en JSON porque asi ocupamos que conteste 
            echo json_encode($roles);
            $stmt->close();
        }
        //cierro conecion con la bd 
        $conn->close();
        break;

    default:
    // si no usan get , esto es un mensaje de que no se puede mandar 
        http_response_code(405); //numero del error 
        echo json_encode(["mensaje" => "Método no permitido. Esta API solo acepta peticiones GET"]); //mensaje a mostrar 
        break;
}
