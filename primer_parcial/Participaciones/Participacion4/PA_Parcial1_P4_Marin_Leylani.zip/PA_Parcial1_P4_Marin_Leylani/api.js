// Selección de elementos del DOM
const btnFetch = document.getElementById('btn-fetch');
const dogContainer = document.getElementById('dog-container');
const loadingDiv = document.getElementById('loading');
const errorMessage = document.getElementById('error-message');

// URL de la API pública Dog CEO para obtener una imagen aleatoria
const API_URL = 'https://dog.ceo/api/breeds/image/random';

// Función para obtener los datos de la API
function obtenerLomito() {
    // Mostrar cargando y limpiar contenedor/errores anteriores
    loadingDiv.classList.remove('hidden');
    errorMessage.classList.add('hidden');
    dogContainer.innerHTML = '';

    fetch(API_URL)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            return response.json(); 
        })
        .then(data => {
            loadingDiv.classList.add('hidden');
            
            crearTarjetaPerro(data.message);
        })
        .catch(error => {
            console.error('Error:', error);
            loadingDiv.classList.add('hidden');
            errorMessage.classList.remove('hidden'); // Mostrar error en pantalla
        });
}

// Función encargada de manipular el DOM de manera dinámica
function crearTarjetaPerro(imageUrl) {
    // Extraer el nombre de la raza desde la URL de la imagen
    const partesUrl = imageUrl.split('/breeds/');
    let nombreRaza = 'Raza Desconocida';
    
    if (partesUrl.length > 1) {
        nombreRaza = partesUrl[1].split('/')[0];
        nombreRaza = nombreRaza.replace('-', ' ');
    }

    // Estructura mejorada con contenedores de diseño modernos [cite: 48, 54]
    const tarjetaHTML = `
        <div class="card">
            <div class="card-image-wrapper">
                <img src="${imageUrl}" alt="Perrito de la API">
            </div>
            <div class="card-content">
                <span class="card-tag">Identificado con éxito</span>
                <h3>${nombreRaza}</h3>
            </div>
        </div>
    `;

    // Inyectar el bloque de código en nuestro contenedor asignado
    dogContainer.insertAdjacentHTML('beforeend', tarjetaHTML);
}

// Registrar el evento 'click' en el botón para generar nuevas peticiones
btnFetch.addEventListener('click', obtenerLomito);

// Ejecutar una vez al cargar la página por primera vez para que no inicie vacía
document.addEventListener('DOMContentLoaded', obtenerLomito);