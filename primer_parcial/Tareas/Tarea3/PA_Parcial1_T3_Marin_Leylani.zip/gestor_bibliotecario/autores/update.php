<?php
require_once "../config/connection.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $id = intval($_POST["id"] ?? 0);
    
    $nombre = htmlspecialchars(trim($_POST["nombre"]));
    $apellido = htmlspecialchars(trim($_POST["apellido"]));
    $nacionalidad = htmlspecialchars(trim($_POST["nacionalidad"]));
    $fecha_nacimiento = htmlspecialchars(trim($_POST["fecha_nacimiento"]));

    $nacionalidad = !empty($nacionalidad) ? $nacionalidad : null;
    $fecha_nacimiento = !empty($fecha_nacimiento) ? $fecha_nacimiento : null;

    if ($id > 0 && !empty($nombre) && !empty($apellido)) {
       
        $sql = "UPDATE autores SET nombre = ?, apellido = ?, nacionalidad = ?, fecha_nacimiento = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("ssssi", $nombre, $apellido, $nacionalidad, $fecha_nacimiento, $id);
            
            if ($stmt->execute()) {
                header("Location: index.php?success=" . urlencode("Autor actualizado correctamente."));
                exit;
            } else {
                header("Location: index.php?error=" . urlencode("Error al guardar las modificaciones en la base de datos."));
                exit;
            }
            $stmt->close();
        } else {
            header("Location: index.php?error=" . urlencode("Error al preparar la consulta de actualización."));
            exit;
        }
    } else {
        header("Location: index.php?error=" . urlencode("Datos inválidos u obligatorios vacíos."));
        exit;
    }
} else {
    header("Location: index.php");
    exit;
}