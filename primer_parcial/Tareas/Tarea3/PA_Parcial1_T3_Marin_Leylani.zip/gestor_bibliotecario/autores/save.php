<?php
require_once "../config/connection.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = htmlspecialchars(trim($_POST["nombre"]));
    $apellido = htmlspecialchars(trim($_POST["apellido"]));
    $nacionalidad = htmlspecialchars(trim($_POST["nacionalidad"]));
    $fecha_nacimiento = htmlspecialchars(trim($_POST["fecha_nacimiento"]));

    $nacionalidad = !empty($nacionalidad) ? $nacionalidad : null;
    $fecha_nacimiento = !empty($fecha_nacimiento) ? $fecha_nacimiento : null;

    
    if (!empty($nombre) && !empty($apellido)) {
        
        $sql = "INSERT INTO autores (nombre, apellido, nacionalidad, fecha_nacimiento) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
           
            $stmt->bind_param("ssss", $nombre, $apellido, $nacionalidad, $fecha_nacimiento);
           
            if ($stmt->execute()) {
                header("Location: index.php?success=" . urlencode("Autor registrado correctamente."));
                exit;
            } else {
                header("Location: index.php?error=" . urlencode("Error al ejecutar la inserción en la base de datos."));
                exit;
            }
            $stmt->close();
        } else {
            header("Location: index.php?error=" . urlencode("Error al preparar la consulta con MySQLi."));
            exit;
        }
    } else {
        header("Location: index.php?error=" . urlencode("Los campos obligatorios (Nombre y Apellido) están vacíos."));
        exit;
    }
} else {
    header("Location: index.php");
    exit;
}