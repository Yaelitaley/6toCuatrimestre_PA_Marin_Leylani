<?php
    require_once "../config/connection.php";

    $sql = "SELECT * FROM autores ORDER BY id DESC";
    $resultado = $conn->query($sql);

    
    $autores = [];
    if ($resultado && $resultado->num_rows > 0) {
        $autores = $resultado->fetch_all(MYSQLI_ASSOC);
    }
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-users"></i> Autores</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Autor
    </a>
</div>

<?php if (isset($_GET["success"])): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php elseif (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Nacionalidad</th>
                <th>Fecha de Nacimiento</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($autores) > 0): ?>
                <?php foreach ($autores as $autor): ?>
                    <tr>
                        <td><?= $autor['id'] ?></td>
                        <td><?= htmlspecialchars($autor['nombre']) ?></td>
                        <td><?= htmlspecialchars($autor['apellido']) ?></td>
                        <td><?= htmlspecialchars($autor['nacionalidad'] ? $autor['nacionalidad'] : 'N/A') ?></td>
                        <td><?= htmlspecialchars($autor['fecha_nacimiento'] ? $autor['fecha_nacimiento'] : 'N/A') ?></td>
                        <td>
                            <a href="edit.php?id=<?= $autor['id'] ?>" class="btn btn-warning btn-sm" title="Editar">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="delete.php?id=<?= $autor['id'] ?>" class="btn btn-danger btn-sm" title="Eliminar" 
                            onclick="return confirm('¿Seguro que deseas eliminar este autor?')">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" style="text-align: center;">No hay autores registrados.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include_once "../includes/footer.php"; ?>