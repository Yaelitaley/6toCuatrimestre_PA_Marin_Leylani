<?php
require_once "../config/connection.php";
$id = intval($_GET["id"] ?? 0);

if ($id > 0) {
    $sql = "DELETE FROM autores WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            header("Location: index.php?success=" . urlencode("Autor eliminado correctamente."));
            exit;
        } else {
            header("Location: index.php?error=" . urlencode("No se pudo eliminar el registro en la base de datos."));
            exit;
        }
        $stmt->close();
    } else {
        header("Location: index.php?error=" . urlencode("Error al preparar la consulta de eliminación."));
        exit;
    }
} else {
    header("Location: index.php?error=" . urlencode("ID de autor no válido."));
    exit;
}